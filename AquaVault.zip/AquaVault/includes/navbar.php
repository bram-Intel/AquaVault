<?php
/**
 * AquaVault Capital - Modern Sidebar Navigation Component
 * Cowrywise-inspired sidebar with hamburger menu
 */
if (!isset($_SESSION)) {
    session_start();
}

// Get current page for active state
$current_page = basename($_SERVER['PHP_SELF']);
?>

<!-- Sidebar Overlay (Mobile) -->
<div id="sidebar-overlay" class="sidebar-overlay"></div>

<!-- Modern Sidebar -->
<aside id="sidebar" class="sidebar">
    <!-- Sidebar Header -->
    <div class="sidebar-header">
        <a href="dashboard.php" class="sidebar-brand">
            <div class="brand-icon">
                <span>AV</span>
            </div>
            <span class="brand-text">AquaVault</span>
        </a>
        <button id="sidebar-close" class="sidebar-close">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
        </button>
    </div>

    <!-- Navigation Menu -->
    <nav class="sidebar-nav">
        <ul class="nav-list">
            <li class="nav-item">
                <a href="dashboard.php" class="nav-link <?php echo $current_page === 'dashboard.php' ? 'active' : ''; ?>">
                    <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="3" width="7" height="7"></rect>
                        <rect x="14" y="3" width="7" height="7"></rect>
                        <rect x="14" y="14" width="7" height="7"></rect>
                        <rect x="3" y="14" width="7" height="7"></rect>
                    </svg>
                    <span class="nav-text">Dashboard</span>
                </a>
            </li>
            
            <li class="nav-item">
                <a href="invest.php" class="nav-link <?php echo $current_page === 'invest.php' ? 'active' : ''; ?>">
                    <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="12" y1="1" x2="12" y2="23"></line>
                        <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                    </svg>
                    <span class="nav-text">Invest</span>
                </a>
            </li>
            
            <li class="nav-item">
                <a href="withdraw.php" class="nav-link <?php echo $current_page === 'withdraw.php' ? 'active' : ''; ?>">
                    <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <polyline points="12,6 12,12 16,14"></polyline>
                    </svg>
                    <span class="nav-text">Withdraw</span>
                </a>
            </li>
            
            <li class="nav-item">
                <a href="withdrawal_requests.php" class="nav-link <?php echo $current_page === 'withdrawal_requests.php' ? 'active' : ''; ?>">
                    <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                        <polyline points="14,2 14,8 20,8"></polyline>
                        <line x1="16" y1="13" x2="8" y2="13"></line>
                        <line x1="16" y1="17" x2="8" y2="17"></line>
                        <polyline points="10,9 9,9 8,9"></polyline>
                    </svg>
                    <span class="nav-text">Requests</span>
                </a>
            </li>
            
            <li class="nav-item">
                <a href="bank_accounts.php" class="nav-link <?php echo $current_page === 'bank_accounts.php' ? 'active' : ''; ?>">
                    <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect>
                        <line x1="1" y1="10" x2="23" y2="10"></line>
                    </svg>
                    <span class="nav-text">Bank Accounts</span>
                </a>
            </li>
            
            <li class="nav-item">
                <a href="profile.php" class="nav-link <?php echo $current_page === 'profile.php' ? 'active' : ''; ?>">
                    <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                        <circle cx="12" cy="7" r="4"></circle>
                    </svg>
                    <span class="nav-text">Profile</span>
                </a>
            </li>
            
            <li class="nav-item">
                <a href="kyc.php" class="nav-link <?php echo $current_page === 'kyc.php' ? 'active' : ''; ?>">
                    <svg class="nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M9 12l2 2 4-4"></path>
                        <path d="M21 12c-1 0-3-1-3-3s2-3 3-3 3 1 3 3-2 3-3 3"></path>
                        <path d="M3 12c1 0 3-1 3-3s-2-3-3-3-3 1-3 3 2 3 3 3"></path>
                        <path d="M12 3c0 1-1 3-3 3s-3-2-3-3 1-3 3-3 3 2 3 3"></path>
                        <path d="M12 21c0-1 1-3 3-3s3 2 3 3-1 3-3 3-3-2-3-3"></path>
                    </svg>
                    <span class="nav-text">KYC</span>
                </a>
            </li>
        </ul>
    </nav>

    <!-- User Section -->
    <?php if (isset($_SESSION['user_id'])): ?>
        <div class="sidebar-user">
            <div class="user-info">
                <div class="user-avatar">
                    <?php if (isset($_SESSION['user_avatar']) && $_SESSION['user_avatar']): ?>
                        <img src="../assets/uploads/avatars/<?php echo htmlspecialchars($_SESSION['user_avatar']); ?>" 
                             alt="Avatar" class="avatar-img">
                    <?php else: ?>
                        <span class="avatar-text">
                            <?php echo strtoupper(substr($_SESSION['user_name'], 0, 1)); ?>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="user-details">
                    <div class="user-name"><?php echo htmlspecialchars($_SESSION['user_name']); ?></div>
                    <div class="user-email"><?php echo htmlspecialchars($_SESSION['user_email'] ?? ''); ?></div>
                </div>
            </div>
            <a href="logout.php" class="logout-btn">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                    <polyline points="16,17 21,12 16,7"></polyline>
                    <line x1="21" y1="12" x2="9" y2="12"></line>
                </svg>
                <span>Logout</span>
            </a>
        </div>
    <?php else: ?>
        <div class="sidebar-auth">
            <a href="login.php" class="auth-link">Login</a>
            <a href="register.php" class="auth-btn">Register</a>
        </div>
    <?php endif; ?>
</aside>

<!-- Top Header Bar -->
<header class="top-header">
    <div class="header-content">
        <button id="sidebar-toggle" class="sidebar-toggle">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="3" y1="6" x2="21" y2="6"></line>
                <line x1="3" y1="12" x2="21" y2="12"></line>
                <line x1="3" y1="18" x2="21" y2="18"></line>
            </svg>
        </button>
        
        <div class="header-title">
            <h1><?php echo ucfirst(str_replace('.php', '', $current_page)); ?></h1>
        </div>
        
        <div class="header-actions">
            <!-- Add any header actions here -->
        </div>
    </div>
</header>

<!-- Main Content Wrapper -->
<div class="main-content-wrapper">
    <main class="main-content">

<script>
// Modern Sidebar Navigation JavaScript
document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebar-toggle');
    const sidebarClose = document.getElementById('sidebar-close');
    const sidebarOverlay = document.getElementById('sidebar-overlay');
    
    // Toggle sidebar
    function toggleSidebar() {
        sidebar.classList.toggle('open');
        sidebarOverlay.classList.toggle('active');
        
        // Force sidebar to be visible with inline styles
        if (sidebar.classList.contains('open')) {
            sidebar.style.left = '0px';
            sidebar.style.transform = 'none';
            sidebar.style.display = 'flex';
            sidebar.style.visibility = 'visible';
            sidebar.style.zIndex = '1001';
        } else {
            sidebar.style.left = '-280px';
            sidebar.style.transform = 'none';
        }
        
        document.body.style.overflow = sidebar.classList.contains('open') ? 'hidden' : '';
    }
    
    // Close sidebar
    function closeSidebar() {
        sidebar.classList.remove('open');
        sidebarOverlay.classList.remove('active');
        sidebar.style.left = '-280px';
        sidebar.style.transform = 'none';
        document.body.style.overflow = '';
    }
    
    // Event listeners
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', toggleSidebar);
    }
    
    if (sidebarClose) {
        sidebarClose.addEventListener('click', closeSidebar);
    }
    
    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', closeSidebar);
    }
    
    // Close sidebar on escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && sidebar.classList.contains('open')) {
            closeSidebar();
        }
    });
    
    // Handle window resize
    function handleResize() {
        // Close sidebar on any resize to ensure consistent behavior
        closeSidebar();
    }
    
    window.addEventListener('resize', handleResize);
    
    // Smooth scroll for navigation links
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            // Close sidebar after navigation on all screen sizes
            setTimeout(closeSidebar, 150);
        });
    });
    
    // Add active state management
    const currentPage = '<?php echo $current_page; ?>';
    const activeLink = document.querySelector(`.nav-link[href*="${currentPage}"]`);
    if (activeLink) {
        activeLink.classList.add('active');
    }
    
    // Add touch support for mobile
    let touchStartX = 0;
    let touchEndX = 0;
    
    document.addEventListener('touchstart', function(e) {
        touchStartX = e.changedTouches[0].screenX;
    });
    
    document.addEventListener('touchend', function(e) {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
    });
    
    function handleSwipe() {
        const swipeThreshold = 50;
        const swipeDistance = touchEndX - touchStartX;
        
        // Swipe right to open sidebar (on all screen sizes)
        if (swipeDistance > swipeThreshold && touchStartX < 50) {
            if (!sidebar.classList.contains('open')) {
                toggleSidebar();
            }
        }
        
        // Swipe left to close sidebar
        if (swipeDistance < -swipeThreshold && sidebar.classList.contains('open')) {
            closeSidebar();
        }
    }
    
    // Sidebar starts closed by default on all screen sizes
});
</script>
