<?php
/**
 * AquaVault Capital - Paystack Webhook Handler
 * Handles payment notifications from Paystack
 */
require_once '../db/connect.php';
require_once '../config/paystack.php';

// Set content type
header('Content-Type: application/json');

// Get the raw POST data
$input = file_get_contents('php://input');
$event = json_decode($input, true);

// Log webhook for debugging
error_log("Paystack Webhook: " . $input);

// Verify webhook signature (optional but recommended)
$signature = $_SERVER['HTTP_X_PAYSTACK_SIGNATURE'] ?? '';
$expected_signature = hash_hmac('sha512', $input, PAYSTACK_SECRET_KEY);

// For testing, we'll log signature mismatch but not block the request
if (!hash_equals($expected_signature, $signature)) {
    error_log("Webhook signature mismatch - Expected: $expected_signature, Received: $signature");
    // Uncomment the lines below for production
    // http_response_code(400);
    // echo json_encode(['error' => 'Invalid signature']);
    // exit();
}

// Handle different event types
switch ($event['event']) {
    case 'charge.success':
        handle_successful_payment($event['data'], $pdo);
        break;
    
    case 'charge.failed':
        handle_failed_payment($event['data'], $pdo);
        break;
    
    default:
        // Log unhandled events
        error_log("Unhandled webhook event: " . $event['event']);
        break;
}

echo json_encode(['status' => 'success']);

/**
 * Handle successful payment
 */
function handle_successful_payment($data, $pdo) {
    $reference = $data['reference'];
    
    try {
        // Check if payment is already processed
        $stmt = $pdo->prepare("SELECT id FROM user_investments WHERE payment_reference = ? AND payment_status = 'paid'");
        $stmt->execute([$reference]);
        
        if ($stmt->fetch()) {
            // Payment already processed
            return;
        }
        
        // Find pending investment with this reference
        $stmt = $pdo->prepare("
            SELECT ui.*, u.email, u.first_name, u.last_name 
            FROM user_investments ui 
            JOIN users u ON ui.user_id = u.id 
            WHERE ui.payment_reference = ? AND ui.payment_status = 'pending'
        ");
        $stmt->execute([$reference]);
        $investment = $stmt->fetch();
        
        if (!$investment) {
            error_log("No pending investment found for reference: $reference");
            return;
        }
        
        // Update investment status
        $stmt = $pdo->prepare("
            UPDATE user_investments 
            SET payment_status = 'paid', status = 'active', updated_at = NOW() 
            WHERE payment_reference = ?
        ");
        $stmt->execute([$reference]);
        
        // Update transaction status
        $stmt = $pdo->prepare("
            UPDATE transactions 
            SET status = 'completed', updated_at = NOW() 
            WHERE payment_reference = ?
        ");
        $stmt->execute([$reference]);
        
        // Update user total invested
        $stmt = $pdo->prepare("UPDATE users SET total_invested = total_invested + ? WHERE id = ?");
        $stmt->execute([$investment['amount'], $investment['user_id']]);
        
        // Log successful activation
        error_log("Investment activated successfully for user {$investment['user_id']}, reference: $reference");
        
        // TODO: Send email notification to user
        
    } catch (PDOException $e) {
        error_log("Webhook payment processing error: " . $e->getMessage());
    }
}

/**
 * Handle failed payment
 */
function handle_failed_payment($data, $pdo) {
    $reference = $data['reference'];
    
    try {
        // Update investment status
        $stmt = $pdo->prepare("
            UPDATE user_investments 
            SET payment_status = 'failed', status = 'cancelled', updated_at = NOW() 
            WHERE payment_reference = ?
        ");
        $stmt->execute([$reference]);
        
        // Update transaction status
        $stmt = $pdo->prepare("
            UPDATE transactions 
            SET status = 'failed', updated_at = NOW() 
            WHERE payment_reference = ?
        ");
        $stmt->execute([$reference]);
        
        // Log failed payment
        error_log("Payment failed for reference: $reference");
        
        // TODO: Send email notification to user about failed payment
        
    } catch (PDOException $e) {
        error_log("Webhook payment failure processing error: " . $e->getMessage());
    }
}
?>
