<?php
/**
 * Test webhook functionality
 */
session_start();
require_once '../db/connect.php';
require_once '../config/paystack.php';
require_once '../includes/auth.php';

// Check if admin is logged in
require_admin();

$success_message = '';
$error_message = '';

// Get pending investments
try {
    $stmt = $pdo->prepare("
        SELECT ui.*, u.email
        FROM user_investments ui
        JOIN users u ON ui.user_id = u.id
        WHERE ui.status = 'pending' AND ui.payment_status = 'pending'
        ORDER BY ui.created_at DESC
        LIMIT 10
    ");
    $stmt->execute();
    $pending_investments = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Pending investments fetch error: " . $e->getMessage());
    $pending_investments = [];
}

// Handle manual webhook simulation
if ($_POST && isset($_POST['simulate_webhook'])) {
    $investment_id = (int)$_POST['investment_id'];
    
    try {
        // Get investment details
        $stmt = $pdo->prepare("
            SELECT ui.*, u.email
            FROM user_investments ui
            JOIN users u ON ui.user_id = u.id
            WHERE ui.id = ?
        ");
        $stmt->execute([$investment_id]);
        $investment = $stmt->fetch();
        
        if ($investment) {
            // Simulate webhook processing
            $reference = $investment['payment_reference'];
            
            // Update investment status
            $stmt = $pdo->prepare("
                UPDATE user_investments 
                SET payment_status = 'paid', status = 'active', updated_at = NOW() 
                WHERE id = ?
            ");
            $stmt->execute([$investment_id]);
            
            // Update transaction status
            $stmt = $pdo->prepare("
                UPDATE transactions 
                SET status = 'completed', updated_at = NOW() 
                WHERE payment_reference = ?
            ");
            $stmt->execute([$reference]);
            
            // Update user total invested
            $stmt = $pdo->prepare("UPDATE users SET total_invested = total_invested + ? WHERE id = ?");
            $stmt->execute([$investment['amount'], $investment['user_id']]);
            
            $success_message = "Investment #$investment_id activated successfully!";
        } else {
            $error_message = "Investment not found.";
        }
    } catch (PDOException $e) {
        error_log("Webhook simulation error: " . $e->getMessage());
        $error_message = 'Error processing webhook: ' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Webhook - AquaVault Capital Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .gradient-bg { background: linear-gradient(135deg, #007BFF 0%, #28A745 100%); }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <?php include '../includes/admin_navbar.php'; ?>

    <div class="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <!-- Header -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-900">Webhook Testing</h1>
            <p class="mt-2 text-gray-600">Test and debug webhook functionality</p>
        </div>

        <!-- Messages -->
        <?php if ($success_message): ?>
            <div class="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                <p class="text-green-600 text-sm"><?php echo htmlspecialchars($success_message); ?></p>
            </div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                <p class="text-red-600 text-sm"><?php echo htmlspecialchars($error_message); ?></p>
            </div>
        <?php endif; ?>

        <!-- Webhook Configuration -->
        <div class="bg-white rounded-lg shadow-lg p-6 mb-8">
            <h2 class="text-xl font-semibold text-gray-900 mb-6">Webhook Configuration</h2>
            
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Webhook URL</label>
                    <input type="text" readonly value="<?php echo WEBHOOK_URL; ?>" 
                           class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700">Callback URL</label>
                    <input type="text" readonly value="<?php echo CALLBACK_URL; ?>" 
                           class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50">
                </div>
                
                <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <h3 class="text-sm font-medium text-yellow-800">Webhook Setup Instructions</h3>
                    <div class="mt-2 text-sm text-yellow-700">
                        <p>1. Go to your Paystack Dashboard</p>
                        <p>2. Navigate to Settings → Webhooks</p>
                        <p>3. Add webhook URL: <code><?php echo WEBHOOK_URL; ?></code></p>
                        <p>4. Select events: <code>charge.success</code> and <code>charge.failed</code></p>
                        <p>5. Save the webhook configuration</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pending Investments -->
        <div class="bg-white rounded-lg shadow-lg p-6">
            <h2 class="text-xl font-semibold text-gray-900 mb-6">Pending Investments (<?php echo count($pending_investments); ?>)</h2>
            
            <?php if (empty($pending_investments)): ?>
                <div class="text-center py-8">
                    <div class="text-4xl mb-4">✅</div>
                    <p class="text-gray-500">No pending investments</p>
                </div>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Reference</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Created</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($pending_investments as $investment): ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                        #<?php echo $investment['id']; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div>
                                            <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($investment['email']); ?></div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        ₦<?php echo number_format($investment['amount']); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo htmlspecialchars($investment['payment_reference']); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo date('M d, Y H:i', strtotime($investment['created_at'])); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <form method="POST" class="inline">
                                            <input type="hidden" name="investment_id" value="<?php echo $investment['id']; ?>">
                                            <button type="submit" 
                                                    name="simulate_webhook"
                                                    onclick="return confirm('Simulate webhook for this investment?')"
                                                    class="text-blue-600 hover:text-blue-900 font-medium">
                                                🔄 Simulate Webhook
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
