<?php
/**
 * AquaVault Capital - Paystack Configuration
 * Secure payment gateway configuration
 */

// Paystack API Configuration
define('PAYSTACK_PUBLIC_KEY', 'pk_test_b460df957d8d91ebbb22eb8693b963825a3ecb23');
define('PAYSTACK_SECRET_KEY', 'sk_test_d0d53b3fbc46a0c904c8df19286801ae3d60e5fc');
define('PAYSTACK_BASE_URL', 'https://api.paystack.co');

// Payment configuration
define('CURRENCY', 'NGN');
define('CALLBACK_URL', 'https://aqua.jenniferfan.us/user/success.php');
define('WEBHOOK_URL', 'https://aqua.jenniferfan.us/api/webhook.php');

/**
 * Initialize Paystack payment
 */
if (!function_exists('initialize_payment')) {
    function initialize_payment($email, $amount, $reference, $callback_url = null) {
        $url = PAYSTACK_BASE_URL . "/transaction/initialize";
        
        $fields = [
            'email' => $email,
            'amount' => $amount * 100, // Convert to kobo
            'reference' => $reference,
            'currency' => CURRENCY,
            'callback_url' => $callback_url ?: CALLBACK_URL
        ];

        $fields_string = http_build_query($fields);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer " . PAYSTACK_SECRET_KEY,
            "Cache-Control: no-cache",
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $result = curl_exec($ch);
        curl_close($ch);

        return json_decode($result, true);
    }
}

/**
 * Verify Paystack payment
 */
if (!function_exists('verify_payment')) {
    function verify_payment($reference) {
        $url = PAYSTACK_BASE_URL . "/transaction/verify/" . rawurlencode($reference);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer " . PAYSTACK_SECRET_KEY,
            "Cache-Control: no-cache",
        ]);

        $result = curl_exec($ch);
        curl_close($ch);

        return json_decode($result, true);
    }
}

/**
 * Generate payment reference
 */
if (!function_exists('generate_payment_reference')) {
    function generate_payment_reference($prefix = 'AV') {
        return $prefix . '_' . time() . '_' . random_int(1000, 9999);
    }
}

/**
 * Create Paystack transfer recipient
 */
if (!function_exists('create_transfer_recipient')) {
    function create_transfer_recipient($type, $name, $account_number, $bank_code) {
        $url = PAYSTACK_BASE_URL . "/transferrecipient";
        
        $fields = [
            'type' => $type, // 'nuban' for Nigerian banks
            'name' => $name,
            'account_number' => $account_number,
            'bank_code' => $bank_code,
            'currency' => CURRENCY
        ];

        $fields_string = http_build_query($fields);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer " . PAYSTACK_SECRET_KEY,
            "Cache-Control: no-cache",
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $result = curl_exec($ch);
        curl_close($ch);

        return json_decode($result, true);
    }
}

/**
 * Initiate Paystack transfer
 */
if (!function_exists('initiate_transfer')) {
    function initiate_transfer($source, $amount, $recipient, $reason = null) {
        $url = PAYSTACK_BASE_URL . "/transfer";
        
        $fields = [
            'source' => $source, // 'balance' to transfer from your balance
            'amount' => $amount * 100, // Convert to kobo
            'recipient' => $recipient,
            'reason' => $reason ?: 'Withdrawal from AquaVault Capital'
        ];

        $fields_string = http_build_query($fields);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer " . PAYSTACK_SECRET_KEY,
            "Cache-Control: no-cache",
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $result = curl_exec($ch);
        curl_close($ch);

        return json_decode($result, true);
    }
}

/**
 * Verify Paystack transfer
 */
if (!function_exists('verify_transfer')) {
    function verify_transfer($transfer_code) {
        $url = PAYSTACK_BASE_URL . "/transfer/" . rawurlencode($transfer_code);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer " . PAYSTACK_SECRET_KEY,
            "Cache-Control: no-cache",
        ]);

        $result = curl_exec($ch);
        curl_close($ch);

        return json_decode($result, true);
    }
}

/**
 * Get list of Nigerian banks
 */
if (!function_exists('get_nigerian_banks')) {
    function get_nigerian_banks() {
        $url = PAYSTACK_BASE_URL . "/bank";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer " . PAYSTACK_SECRET_KEY,
            "Cache-Control: no-cache",
        ]);

        $result = curl_exec($ch);
        curl_close($ch);

        return json_decode($result, true);
    }
}

/**
 * Resolve bank account number
 */
if (!function_exists('resolve_bank_account')) {
    function resolve_bank_account($account_number, $bank_code) {
        $url = PAYSTACK_BASE_URL . "/bank/resolve?account_number=" . urlencode($account_number) . "&bank_code=" . urlencode($bank_code);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer " . PAYSTACK_SECRET_KEY,
            "Cache-Control: no-cache",
        ]);

        $result = curl_exec($ch);
        curl_close($ch);

        return json_decode($result, true);
    }
}
?>